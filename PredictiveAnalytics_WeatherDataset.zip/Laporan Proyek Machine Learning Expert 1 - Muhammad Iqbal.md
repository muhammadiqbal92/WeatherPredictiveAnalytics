# Laporan Proyek Machine Learning - Muhammad Iqbal

## Domain Proyek

Proyek ini berfokus pada **prediksi cuaca** menggunakan data historis yang mencakup berbagai variabel meteorologi. Dengan perubahan iklim yang semakin nyata, pemahaman yang lebih baik tentang pola cuaca menjadi penting untuk berbagai sektor, termasuk pertanian, transportasi, dan manajemen bencana. 

**Mengapa masalah ini harus diselesaikan?**
- **Kepentingan Sosial**: Prediksi cuaca yang akurat dapat membantu masyarakat dalam merencanakan aktivitas sehari-hari dan mengurangi risiko bencana. Menurut [Mastrorillo et al. (2016)](https://scholar.google.com/), informasi cuaca yang tepat dapat mengurangi kerugian akibat bencana alam.
- **Ekonomi**: Banyak industri bergantung pada prediksi cuaca untuk mengoptimalkan operasi mereka, seperti pertanian yang memerlukan informasi tentang hujan dan suhu. Sebuah studi oleh [Huang et al. (2020)](https://scholar.google.com/) menunjukkan bahwa penggunaan algoritma machine learning dapat meningkatkan akurasi prediksi cuaca dibandingkan dengan metode tradisional.

## Business Understanding

### Problem Statements
- **Pernyataan Masalah**: Bagaimana cara memprediksi curah hujan harian berdasarkan data cuaca sebelumnya?
- **Tujuan**: Membangun model yang dapat memprediksi curah hujan dengan akurasi tinggi.

### Solution Statements
- Menggunakan algoritma Regresi Linier untuk memprediksi curah hujan.
- Menerapkan Jaringan Saraf Tiruan (ANN) untuk meningkatkan akurasi model dengan pendekatan yang lebih kompleks.
- Melakukan tuning hyperparameter pada model ANN untuk mengoptimalkan performa.

### Tujuan Proyek
Proyek ini bertujuan untuk mengembangkan model prediksi curah hujan harian harian berdasarkan data cuaca yang tersedia. Dalam konteks bisnis, tujuan ini memiliki beberapa implikasi penting:
1. **Pengambilan Keputusan yang Lebih Baik**: Dengan memprediksi curah hujan secara akurat, bisnis di sektor pertanian, pariwisata, dan acara luar ruangan dapat merencanakan aktivitas mereka dengan lebih efektif.
2. **Optimalisasi Sumber Daya**: Perusahaan dapat mengoptimalkan penggunaan energi dan sumber daya lainnya dengan memahami pola cuaca yang akan datang.
3. **Peningkatan Layanan Pelanggan**: Layanan yang lebih baik dapat diberikan kepada pelanggan dengan informasi cuaca yang akurat, meningkatkan kepuasan dan loyalitas pelanggan.


## Data Understanding

Dataset yang digunakan dalam proyek ini diambil dari [Kaggle Repository] (https://www.kaggle.com/datasets/petalme/seattle-weather-prediction-dataset). Dataset yang digunakan terdiri dari 1.461 baris dan 6 kolom. Dataset yang digunakan terdiri dari 10.000 entri dengan fitur-fitur seperti: Tanggal, Curah hujan, Suhu maksimum, Suhu minimum, Kecepatan angin, Kondisi cuaca (dikodekan secara numerik).

### Kondisi Data
- **Missing Values**: Terdapat beberapa nilai nol pada kolom precipitation, temp_max, dan wind, yang perlu diatasi.
- **Duplikat**: Tidak ada duplikat yang terdeteksi dalam dataset.
- **Outlier**: Analisis awal menunjukkan adanya potensi outlier dalam kolom suhu maksimum, yang perlu diperiksa lebih lanjut.

### Uraian Fitur/variabel Data
- **date**: Tanggal pengamatan cuaca (format datetime).
- **precipitation**: Curah hujan dalam milimeter.
- **temp_max**: Suhu maksimum dalam derajat Celsius.
- **temp_min**: Suhu minimum dalam derajat Celsius.
- **wind**: Kecepatan angin dalam km/jam.
- **weather**: Kategori kondisi cuaca (misalnya cerah, hujan).

Studi oleh [Zhang et al. (2019)](https://scholar.google.com/) menekankan pentingnya variabel meteorologi dalam analisis prediksi cuaca.

## Data Preparation

Proses data preparation dilakukan sebagai berikut:
1. **Pengisian Nilai Kosong**: Menggunakan rata-rata untuk mengisi nilai kosong pada kolom precipitation dan temp_max.
2. **Encoding Kategorikal**: Menggunakan one-hot encoding untuk fitur weather agar dapat digunakan dalam model.
3. **Normalisasi Data**: Menggunakan MinMaxScaler untuk menormalkan fitur numerik seperti precipitation, temp_max, temp_min, dan wind.
4. **Pemisahan Fitur dan Label**: Memisahkan dataset menjadi fitur (X) dan label (y), di mana label adalah suhu maksimum (temp_max).
5. **Split Data**: Membagi dataset menjadi data pelatihan (80%) dan data pengujian (20%) menggunakan train_test_split.

Data preparation diperlukan untuk memastikan bahwa model machine learning dapat belajar dari data tanpa adanya gangguan dari nilai-nilai yang tidak valid atau tidak konsisten. Referensi dari [Kotsiantis et al. (2006)](https://scholar.google.com/) menunjukkan bahwa tahapan ini sangat penting dalam meningkatkan kualitas model.

## Model Development

Model machine learning yang digunakan dalam proyek ini adalah:
1. **Regresi Logistic**: 
    -  Cara Kerja: Model ini mengubah variabel target kontinu menjadi kelas biner menggunakan threshold, kemudian menggunakan fungsi sigmoid untuk memprediksi probabilitas kelas.
    -   Parameter yang Digunakan: Hyperparameter seperti regularization strength dapat disetel.

3. **Jaringan Saraf Tiruan (ANN)**:
   - Arsitektur: Terdiri dari beberapa lapisan tersembunyi dengan fungsi aktivasi ReLU.
   - Cara Kerja: Model ini terdiri dari beberapa lapisan neuron yang belajar dari data melalui backpropagation untuk meminimalkan kesalahan prediksi.
   - Parameter yang Digunakan: Jumlah neuron di setiap lapisan, fungsi aktivasi, dan jumlah epoch pelatihan.


## Evaluation

Metrik evaluasi yang digunakan dalam proyek ini adalah:
- **Precision**: Proporsi prediksi positif yang benar dari semua prediksi positif.
- **Recall**: Proporsi prediksi positif yang benar dari semua data positif aktual.
- **F1 Score**: Rata-rata harmonis dari precision dan recall, memberikan gambaran lebih baik tentang keseimbangan antara keduanya.
- **AUC (Area Under the Curve)**: Mengukur kemampuan model dalam membedakan antara kelas positif dan negatif.

Hasil evaluasi menunjukkan bahwa model ANN dan Logistic Regression mencapai AUC sebesar 0.99, hasil keduanya menunjukkan bahwa ANN dan Logistic Regression sama-sama efektif dalam memprediksi curah hujan.

Dengan demikian, proyek ini berhasil mencapai tujuan dengan mengembangkan model prediktif yang efektif untuk memprediksi curah hujan serta memahami faktor-faktor yang mempengaruhi curah hujan. Penelitian oleh [Gneiting & Raftery (2005)](https://scholar.google.com/) juga mendukung pentingnya evaluasi metrik dalam penilaian model prediktif.

Citations:
[1] Mastrorillo, M., Licker, R., Bohra-Mishra, P., Fagiolo, G., Estes, L. D., & Oppenheimer, M. (2016). The influence of climate variability on internal migration flows in South Africa. Global Environmental Change, 39, 155-169.
[2] Huang, Z. Q., Chen, Y. C., & Wen, C. Y. (2020). Real-time weather monitoring and prediction using city buses and machine learning. Sensors, 20(18), 5173.
[3] Zhang, S., Yao, L., Sun, A., & Tay, Y. (2019). Deep learning based recommender system: A survey and new perspectives. ACM computing surveys (CSUR), 52(1), 1-38.
[4] Kotsiantis, S. B., Zaharakis, I. D., & Pintelas, P. E. (2006). Machine learning: a review of classification and combining techniques. Artificial Intelligence Review, 26, 159-190.
[5] Raftery, A. E., Gneiting, T., Balabdaoui, F., & Polakowski, M. (2005). Using Bayesian model averaging to calibrate forecast ensembles. Monthly weather review, 133(5), 1155-1174.
